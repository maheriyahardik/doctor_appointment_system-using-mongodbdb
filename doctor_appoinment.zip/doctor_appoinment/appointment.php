<?php
include 'db.php'; // MongoDB connection

$doctors = $db->doctors->find();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Appointment</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: var(--primary-color);
            font-size: 28px;
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table th, table td {
            padding: 14px 20px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background-color: var(--primary-color);
            color: var(--white);
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        button {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: var(--primary-color);
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            text-align: center;
            background-color: var(--dark);
            color: var(--white);
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background-color: var(--primary-color);
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Book Appointment
</header>


<div class="container">
    <h2>Available Doctors</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Speciality</th>
            <th>Email</th>
            <th>Action</th>
        </tr>
        <?php foreach ($doctors as $doc): ?>
            <tr>
                <td><?= htmlspecialchars($doc['name']) ?></td>
                <td><?= htmlspecialchars($doc['speciality']) ?></td>
                <td><?= htmlspecialchars($doc['email']) ?></td>
                <td>
                    <form method="GET" action="book.php">
                        <input type="hidden" name="doctor" value="<?= htmlspecialchars($doc['name']) ?>">
                        <button type="submit">Book Now</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div style="text-align: center;">
        <a href="home.php" class="back-link">Back to Home</a>
    </div>
</div>

<footer>
    &copy; <?php echo date('Y'); ?> Doctor Appointment System. Developed by YourCompanyName.
</footer>

</body>
</html>
