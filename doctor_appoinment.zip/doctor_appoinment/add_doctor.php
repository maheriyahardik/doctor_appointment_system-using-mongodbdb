<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin'])) header('Location: login.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $db->doctors->insertOne([
        'name' => $_POST['name'],
        'speciality' => $_POST['speciality'],
        'email' => $_POST['email'],
    ]);
    $msg = "Doctor added successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Doctor - Admin</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 600px;
            margin: 50px auto;
            padding: 40px;
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input, button {
            margin-bottom: 20px;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }

        button {
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: var(--secondary-color);
        }

        .success {
            color: green;
            text-align: center;
            margin-bottom: 20px;
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }
    </style>
</head>
<body>

<header>
    Admin - Add Doctor
</header>

<div class="container">
    <h2>Add Doctor</h2>

    <?php if (!empty($msg)) echo "<p class='success'>$msg</p>"; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Doctor Name" required>
        <input type="text" name="speciality" placeholder="Speciality" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit">Add Doctor</button>
    </form>

    <div class="back-link">
        <a href="dashboard.php">← Back to Dashboard</a>
    </div>
</div>

<footer>
    &copy; <?= date('Y') ?> Doctor Appointment System. 
</footer>

</body>
</html>
