<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin'])) header('Location: login.php');

$appointments = $db->appointments->find();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointments - Admin</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: var(--primary-color);
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
        }

        .button:hover {
            background-color: var(--secondary-color);
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Doctor Appointment System - View Appointments
</header>


<div class="container">
    <h2>Appointments List</h2>
    <table>
        <tr>
            <th>Doctor</th>
            <th>Date</th>
            <th>Time</th>
        </tr>
        <?php foreach ($appointments as $a): ?>
        <tr>
            <td><?= htmlspecialchars($a['doctor']) ?></td>
            <td><?= htmlspecialchars($a['date']) ?></td>
            <td><?= htmlspecialchars($a['time']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <div style="text-align: center;">
        <a class="button" href="dashboard.php">Back to Dashboard</a>
    </div>
</div>

<footer>
    &copy; <?= date('Y') ?> Doctor Appointment System. Developed by YourCompanyName. | <a href="about.php">Learn More</a>
</footer>

</body>
</html>
