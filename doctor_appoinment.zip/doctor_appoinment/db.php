
<?php
require 'vendor/autoload.php'; // MongoDB library (composer install mongodb/mongodb)

$client = new MongoDB\Client("mongodb://localhost:27017");

$db = $client->doctor_appointment_system; // Database name
$usersCollection = $db->users;
$appointmentsCollection = $db->appointments;
$feedbackCollection = $db->feedbacks;
$doctorsCollection = $db->doctors;
?>
