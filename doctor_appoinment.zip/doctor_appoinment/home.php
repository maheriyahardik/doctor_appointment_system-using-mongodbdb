<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - Doctor Appointment</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .hero {
            background: url('https://images.unsplash.com/photo-1588776814546-ec7e0b2d75b1?crop=entropy&cs=tinysrgb&fit=crop&h=600&w=1600') no-repeat center center/cover;
            height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
            font-size: 36px;
            font-weight: bold;
        }

        .container {
            flex: 1;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .section {
            margin-bottom: 40px;
            text-align: center;
        }

        .section h2 {
            color: var(--primary-color);
            font-size: 28px;
            margin-bottom: 20px;
        }

        .section p {
            color: var(--text-color);
            font-size: 18px;
            line-height: 1.6;
        }

        .services {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .service {
            background-color: var(--bg-color);
            padding: 20px;
            border-radius: 8px;
            width: 250px;
            margin: 10px;
            text-align: center;
            transition: transform 0.3s;
        }

        .service:hover {
            transform: translateY(-8px);
            background-color: #e0f7e9;
        }

        .service img {
            width: 100px;
            margin-bottom: 15px;
        }

        .welcome-message {
            font-size: 26px;
            color: var(--primary-color);
            margin-bottom: 10px;
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Doctor Appointment System
</header>

<nav>
    <a href="profile.php">Profile</a>
    <a href="appointment.php">Appointments</a>
    <a href="about.php">About</a>
    <a href="feedback.php">Feedback</a>
    <a href="logout.php">Logout</a>
</nav>

<div class="container">
    <div class="section">
        
<div class="">
    Welcome, <?php echo htmlspecialchars($_SESSION['user']['name']); ?>!
</div>

        <h2>About Our Service</h2>
        <p>
            Manage your health journey with ease. Book appointments, consult top doctors, and get the best healthcare experience online!
        </p>
    </div>

    <div class="section">
        <h2>Our Services</h2>
        <div class="services">
            <div class="service">
                <img src="https://cdn-icons-png.flaticon.com/512/2874/2874827.png" alt="Booking">
                <h3>Easy Booking</h3>
                <p>Schedule appointments at your convenience with just a few clicks.</p>
            </div>

            <div class="service">
                <img src="https://cdn-icons-png.flaticon.com/512/1037/1037970.png" alt="Consultation">
                <h3>Consult Experts</h3>
                <p>Connect with certified and experienced doctors for your needs.</p>
            </div>

            <div class="service">
                <img src="https://cdn-icons-png.flaticon.com/512/4298/4298890.png" alt="Profile Management">
                <h3>Profile Management</h3>
                <p>Keep your medical records and appointments updated anytime.</p>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>Why Choose Us?</h2>
        <p>
            Trusted by thousands of patients. We ensure seamless service, expert consultations, and top-notch healthcare support.
        </p>
    </div>
</div>

<footer>
    &copy; <?php echo date('Y'); ?> Doctor Appointment System. Developed by YourCompanyName. | <a href="about.php">Learn More</a>
</footer>

</body>
</html>
