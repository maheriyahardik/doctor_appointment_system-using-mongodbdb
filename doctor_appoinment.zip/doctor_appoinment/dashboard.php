<?php
session_start();
if (!isset($_SESSION['admin'])) header('Location: login.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Doctor Appointment</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 800px;
            margin: 50px auto;
            padding: 40px;
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: var(--primary-color);
            font-size: 32px;
            margin-bottom: 30px;
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Admin Dashboard
</header>

<nav>
    <a href="add_doctor.php">Add Doctor</a>
    <a href="view_doctor.php">View Doctors</a>
    <a href="view_appointment.php">View Appointments</a>
    <a href="view_feedback.php">View Feedback</a>
    <a href="logout.php">Logout</a>
</nav>

<div class="container">
    <h2>Welcome, Admin!</h2>
    <p>Use the navigation links above to manage the system.</p>
</div>

<footer>
    &copy; <?= date('Y') ?> Doctor Appointment System. Developed by YourCompanyName.
</footer>

</body>
</html>
