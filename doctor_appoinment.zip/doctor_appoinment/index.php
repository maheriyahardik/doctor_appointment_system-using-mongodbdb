<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userscollection = $db->users;
    $user = $userscollection->findOne(['email' => $_POST['email']]);

    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user'] = [
            'id' => (string) $user['_id'],
            'name' => $user['name'],
            'email' => $user['email']
        ];
        header('Location: home.php');
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Doctor Appointment</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 400px;
            margin: 50px auto;
            padding: 30px 20px;
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: var(--primary-color);
            font-size: 28px;
            margin-bottom: 20px;
        }

        form {
            margin-top: 20px;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        button {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: var(--primary-color);
        }

        p {
            margin-top: 20px;
            font-size: 15px;
        }

        p a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
        }

        p a:hover {
            text-decoration: underline;
        }

        .error {
            margin-top: 20px;
            color: red;
            font-weight: bold;
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Doctor Appointment Login
</header>


<div class="container">
    <h2>Login</h2>

    <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Enter your Email" required>
        <input type="password" name="password" placeholder="Enter your Password" required>
        <button type="submit">Login</button>
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
</div>

<footer>
    &copy; <?= date('Y') ?> Doctor Appointment System. Developed by YourCompanyName.
</footer>

</body>
</html>
