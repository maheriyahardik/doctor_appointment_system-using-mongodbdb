<?php
include 'db.php'; // Use the shared db connection
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $db->feedbacks->insertOne([
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'message' => $_POST['message'],
        'date' => date('Y-m-d H:i:s')
    ]);
    $msg = "Thank you for your feedback!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Feedback</title>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #388E3C;
            --text-color: #555;
            --bg-color: #f4f4f9;
            --white: #fff;
            --dark: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 30px 20px;
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }

        nav {
            display: flex;
            justify-content: center;
            background-color: var(--dark);
            flex-wrap: wrap;
        }

        nav a {
            color: var(--white);
            padding: 16px 24px;
            text-decoration: none;
            font-size: 17px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: var(--primary-color);
        }

        .container {
            flex: 1;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: var(--primary-color);
            font-size: 28px;
            text-align: center;
            margin-bottom: 20px;
        }

        form label {
            display: block;
            font-weight: bold;
            margin: 15px 0 5px;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: var(--primary-color);
        }

        .message {
            margin-top: 20px;
            color: green;
            text-align: center;
            font-weight: bold;
        }

        .back-link {
            display: inline-block;
            margin-top: 30px;
            text-align: center;
            background-color: var(--dark);
            color: var(--white);
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background-color: var(--primary-color);
        }

        footer {
            background-color: var(--dark);
            color: var(--white);
            text-align: center;
            padding: 15px;
            font-size: 15px;
            margin-top: auto;
        }

        footer a {
            color: var(--primary-color);
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Submit Feedback
</header>


<div class="container">
    <h2>Give Us Your Feedback</h2>
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Message:</label>
        <textarea name="message" rows="5" required></textarea>

        <button type="submit">Submit</button>
    </form>

    <?php if (!empty($msg)) echo "<div class='message'>$msg</div>"; ?>

    <div style="text-align:center;">
        <a href="home.php" class="back-link">Back to Home</a>
    </div>
</div>

<footer>
    &copy; <?= date('Y') ?> Doctor Appointment System. Developed by YourCompanyName.
</footer>

</body>
</html>
