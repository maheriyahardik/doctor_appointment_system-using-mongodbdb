<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About - Doctor Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 28px;
        }

        .container {
            flex: 1;
            max-width: 1000px;
            margin: 30px auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 20px;
            font-size: 32px;
        }

        p {
            font-size: 18px;
            color: #555;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .back-link {
            display: inline-block;
            padding: 12px 25px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            font-size: 16px;
            border-radius: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background-color: #388E3C;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 12px;
            font-size: 14px;
        }

        footer a {
            color: #4CAF50;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<header>
    Doctor Appointment System
</header>

<main>
    <div class="container">
        <h2>About Us</h2>
        <p>We provide an easy and convenient platform to book online doctor appointments for your health needs. Our mission is to connect patients with qualified healthcare professionals and ensure timely medical assistance.</p>
        <a href="home.php" class="back-link">Back to Home</a>
    </div>
</main>

<footer>
    &copy; <?php echo date('Y'); ?> Doctor Appointment System. All rights reserved.
</footer>

</body>
</html>
