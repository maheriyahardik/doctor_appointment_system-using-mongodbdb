<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <style>
    :root {
        --primary-color: #4CAF50;
        --secondary-color: #388E3C;
        --text-color: #555;
        --bg-color: #f4f4f9;
        --white: #fff;
        --dark: #333;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: var(--bg-color);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    header {
        background-color: var(--primary-color);
        color: var(--white);
        padding: 30px 20px;
        text-align: center;
        font-size: 32px;
        font-weight: bold;
        letter-spacing: 1px;
    }

    .container {
        flex: 1;
        max-width: 600px;
        margin: 40px auto;
        padding: 20px;
        background: var(--white);
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    h2 {
        color: var(--primary-color);
        font-size: 28px;
        margin-bottom: 20px;
    }

    .profile-info {
        font-size: 18px;
        margin-top: 20px;
        text-align: left;
    }

    .profile-info p {
        margin-bottom: 15px;
    }

    .profile-info strong {
        color: var(--primary-color);
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 30px;
        background-color: var(--primary-color);
        color: #fff;
        font-size: 16px;
        text-decoration: none;
        border-radius: 50px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .back-link:hover {
        background-color: var(--secondary-color);
        transform: translateY(-2px);
    }

    footer {
        background-color: var(--dark);
        color: #aaa;
        text-align: center;
        padding: 15px 10px;
        font-size: 14px;
    }

    footer a {
        color: var(--primary-color);
        text-decoration: none;
    }

    footer a:hover {
        text-decoration: underline;
    }
</style>

</head>
<body>

<header>
    <h1>Welcome to Your Profile</h1>
    
</header>

<main>
    <div class="container">
        <h2>Profile Details</h2>
        <div class="profile-info">
            <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['user']['name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['user']['email']); ?></p>
        </div>
        <a href="home.php" class="back-link">Back to Home</a>
    </div>
</main>

<footer>
    &copy; <?php echo date('Y'); ?> MyWebsite. All rights reserved. | <a href="home.php">Home</a>
</footer>

</body>
</html>
